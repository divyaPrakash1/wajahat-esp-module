export class Persona {
  public id!: number;
  public type!: string;
  public orgId!: number;
  public orgName!: string;
  public orgImageUrl!: string;
  public locales!: string;
}
