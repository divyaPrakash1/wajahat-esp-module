export class User {
  constructor() {}
  UserId!: number;
  UserProfilePicture!: string;
  UserProfilePictureUrl!: string;
  UserFirstName!: string;
  UserLastName!: string;
  UserOrganization_OrganizationId!: number;

  // id: number;
  // profilePicture: string;
  // profilePictureUrl: string;
  // firstName: string;
  // lastName: string;
  // organizationId: number;
}
