export class Response {
  constructor() {}
  ResponseResult: any;
  ResponseMessage: string;
  ResponseError: string;
  ResponseCode: number;
}
