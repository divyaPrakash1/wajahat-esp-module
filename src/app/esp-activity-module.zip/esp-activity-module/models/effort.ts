export class Effort {
  creationDate!: string;
  endTime!: string;
  hours!: number;
  id!: number;
  minutes!: number;
  note!: string;
  startTime!: string;
  completedDate!: string;
  startTimeDate!: string;
  endTimeDate!: string;
  constructor() {}
}
