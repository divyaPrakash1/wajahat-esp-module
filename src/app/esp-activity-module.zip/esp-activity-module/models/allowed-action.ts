export class AllowedAction {
  id!: number;
  name!: string;
  constructor() {}
}
