export class CurrencyModel {
	public id!: number;
	public name!: string;
	public code!: string;
	public rateToBase!: number;
  public isBase!: boolean;
  public symobl!: string;
  public isDisabled!: boolean;
}
