export class Category {
  id!: number;
  text!: string;

  constructor() {}
}
