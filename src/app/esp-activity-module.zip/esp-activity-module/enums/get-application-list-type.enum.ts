export enum GetApplicationListType {
  Assigned = 3,
  Closed = 2,
  Open = 1
}
