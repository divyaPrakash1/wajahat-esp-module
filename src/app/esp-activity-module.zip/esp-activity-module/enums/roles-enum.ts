
export enum Roles {
  Admin = "Admin",
  User = 'User',
  Applicant='Applicant'
}
